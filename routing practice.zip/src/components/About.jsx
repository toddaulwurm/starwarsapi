// import React from "react";

const About = props => {
    return (<h1 style={{color: "blue"}}>About Component Loaded</h1>)
}
export default About;