// import React from "react";

const Home = props => {
    return (<h1 style={{color: "red"}}>Home Component Loaded</h1>)
}
export default Home;