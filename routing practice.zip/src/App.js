import './App.css';
// import React, { useState } from "react";
import {
  BrowserRouter,
  Switch,
  Route,
  Link,
} from "react-router-dom";
import Home from './components/Home';
import About from './components/About';
import Location from './components/Location';



function App() {
  return (
    <BrowserRouter>
      <h1>Routing Example</h1>
      <p>
        <Link to="/">Home</Link>
        {" | "}
        <Link to="/about">About</Link> 
        {" | "}
        <Link to="/seattle">Seattle</Link>
        {" | "}
        <Link to="/chicago">Chicago</Link>
        {" | "}   
        <Link to="/burbank">Burbank</Link>
      </p>

      <Switch>
        <Route path="/about">
          <About />
        </Route>
        <Route path="/:city">
            <Location/>
        </Route>
        <Route exact path="/">
            <Home />
        </Route>
      </Switch>
    </BrowserRouter>
  );
}

export default App;
